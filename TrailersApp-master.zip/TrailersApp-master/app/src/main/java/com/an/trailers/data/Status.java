package com.an.trailers.data;

public enum Status {
    SUCCESS,
    ERROR,
    LOADING
}