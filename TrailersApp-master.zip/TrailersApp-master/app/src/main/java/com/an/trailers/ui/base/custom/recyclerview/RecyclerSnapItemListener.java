package com.an.trailers.ui.base.custom.recyclerview;

public interface RecyclerSnapItemListener {
    void onItemSnap(int position);
}
