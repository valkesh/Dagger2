package com.an.trailers.ui.base;

import android.support.v7.app.AppCompatActivity;

import com.an.trailers.AppConstants;

public class BaseActivity extends AppCompatActivity implements AppConstants {
}
